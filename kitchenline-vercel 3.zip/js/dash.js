(function () {
  var ROLES = [
    { href: "owner.html", label: "Owner" },
    { href: "customer.html", label: "Customer" },
    { href: "staff.html", label: "Staff" },
    { href: "kitchen.html", label: "Kitchen" },
    { href: "manager.html", label: "Manager" },
    { href: "inventory.html", label: "Inventory" },
    { href: "host.html", label: "Reservations" },
    { href: "vendor.html", label: "Vendor" },
    { href: "rider.html", label: "Rider" },
    { href: "reviews.html", label: "Reviews" }
  ];

  window.toast = function (msg) {
    var t = document.querySelector(".toast");
    if (!t) {
      t = document.createElement("div");
      t.className = "toast";
      document.body.appendChild(t);
    }
    t.textContent = msg;
    t.classList.add("on");
    window.setTimeout(function () { t.classList.remove("on"); }, 2400);
  };

  window.bindReset = function () {
    var btn = document.querySelector("[data-reset]");
    if (!btn) return;
    btn.addEventListener("click", function () {
      window.KL.reset();
      window.toast("Demo data reset");
      window.setTimeout(function () { location.reload(); }, 400);
    });
  };

  window.onStore = function (fn) {
    fn(window.KL.get());
    window.addEventListener("kl-change", function () { fn(window.KL.get()); });
    window.addEventListener("storage", function () { fn(window.KL.get()); });
  };

  function injectNav() {
    if (document.querySelector(".role-nav")) return;
    var file = (location.pathname.split("/").pop() || "index.html");
    var inRole = /characters/.test(location.pathname) || file !== "index.html";
    var prefix = inRole ? "" : "characters/";
    var bar = document.createElement("nav");
    bar.className = "role-nav";
    bar.setAttribute("aria-label", "All role dashboards");
    bar.innerHTML = ROLES.map(function (r) {
      var href = prefix + r.href;
      var active = file === r.href ? " on" : "";
      return '<a class="chip' + active + '" href="' + href + '">' + r.label + "</a>";
    }).join("");
    var host = document.querySelector(".topbar") || document.body;
    host.insertAdjacentElement("afterend", bar);
  }

  document.addEventListener("DOMContentLoaded", function () {
    injectNav();
    window.bindReset();
  });
})();
