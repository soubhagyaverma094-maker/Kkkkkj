(function () {
  var KEY = "kitchenline-demo-v2";

  function seed() {
    return {
      sales: 184600,
      orders: 142,
      lastWeek: 164800,
      cash: 38900,
      upi: 141200,
      refunds: 4500,
      reviews: [5, 5, 4, 5, 2, 5, 4, 5, 5, 5, 4, 5, 5, 3, 5, 4, 5, 5],
      noshows: 1,
      hourly: [4200, 6100, 8800, 12400, 16200, 19800, 17600, 15400, 21100, 24600, 22800, 15600],
      dishes: [
        { name: "Butter Chicken", sold: 40, rev: 17960 },
        { name: "Dal Makhani", sold: 36, rev: 10404 },
        { name: "Garlic Naan", sold: 62, rev: 4959 },
        { name: "Paneer Tikka", sold: 22, rev: 7238 },
        { name: "Cold coffee", sold: 28, rev: 1372 }
      ],
      stock: [
        { name: "Chicken", unit: "kg", qty: 14, par: 20 },
        { name: "Cream", unit: "L", qty: 1.4, par: 8 },
        { name: "Naan flour", unit: "kg", qty: 3, par: 12 },
        { name: "Paneer", unit: "kg", qty: 6, par: 8 }
      ],
      kots: [
        { id: 142, table: "T7", items: "Butter Chicken, Cold coffee", status: "fire", paid: 498, start: Date.now() - 180000 },
        { id: 143, table: "Del", items: "2x Dal Makhani, Naan", status: "hold", paid: 667, start: Date.now() - 420000 }
      ],
      tables: [
        { id: 1, state: "busy", label: "4 pax" },
        { id: 2, state: "free", label: "Free" },
        { id: 3, state: "held", label: "8:00 · 4" },
        { id: 4, state: "busy", label: "2 pax" },
        { id: 5, state: "free", label: "Free" },
        { id: 6, state: "free", label: "Free" },
        { id: 7, state: "busy", label: "QR order" },
        { id: 8, state: "held", label: "8:45 · 2" }
      ],
      staff: [
        { id: "A", role: "Waiter", status: "in", at: "09:58", loc: "18m", face: "" },
        { id: "B", role: "Waiter", status: "fail", at: "09:51", loc: "1.8km", face: "" },
        { id: "C", role: "Host", status: "in", at: "09:40", loc: "12m", face: "" }
      ],
      pos: [
        { id: 208, vendor: "Dairy vendor", items: "Cream 12L, flour 25kg", status: "sent", amt: 4820 }
      ],
      runs: [
        { id: 143, drop: "Bandra West 3.1km", status: "ready", eta: 18 }
      ],
      crm: [
        { seg: "New", n: 18 },
        { seg: "Regular", n: 64 },
        { seg: "Lapsed", n: 21 },
        { seg: "High-value", n: 9 }
      ],
      payments: [
        { id: 1, type: "upi", amt: 498, table: "T7", note: "KOT 142" },
        { id: 2, type: "refund", amt: 4500, table: "T4", note: "Naan cold" }
      ],
      eightySix: [],
      points: 240,
      birthday: 12,
      outlet: "all",
      service: "all",
      lastPay: 0,
      log: ["Night close ready", "KOT 142 paid T7", "Staff B geofence fail"]
    };
  }

  function load() {
    try {
      var raw = localStorage.getItem(KEY);
      if (raw) {
        var parsed = JSON.parse(raw);
        var base = seed();
        Object.keys(base).forEach(function (k) {
          if (parsed[k] === undefined) parsed[k] = base[k];
        });
        return parsed;
      }
    } catch (e) {}
    var s = seed();
    save(s);
    return s;
  }

  function save(s) {
    localStorage.setItem(KEY, JSON.stringify(s));
    window.dispatchEvent(new CustomEvent("kl-change"));
  }

  function avg(arr) {
    if (!arr.length) return 0;
    return arr.reduce(function (a, b) { return a + b; }, 0) / arr.length;
  }

  function share(s) {
    var o = s.outlet === "andheri" ? 0.3 : (s.outlet === "bandra" ? 0.7 : 1);
    var svc = s.service === "lunch" ? 0.38 : (s.service === "dinner" ? 0.62 : 1);
    return o * svc;
  }

  window.KL = {
    get: load,
    save: save,
    reset: function () {
      var s = seed();
      save(s);
      return s;
    },
    money: function (n) {
      return "₹" + Math.round(n).toLocaleString("en-IN");
    },
    ticket: function (s) {
      return s.orders ? Math.round(s.sales / s.orders) : 0;
    },
    rating: function (s) {
      return avg(s.reviews).toFixed(1);
    },
    share: share,
    viewSales: function (s) {
      return Math.round(s.sales * share(s));
    },
    addOrder: function (items, total, table, split) {
      var s = load();
      s.sales += total;
      s.orders += 1;
      s.upi += total;
      s.hourly[s.hourly.length - 1] += total;
      s.lastPay = total;
      var id = 140 + s.kots.length + s.orders;
      s.kots.unshift({ id: id, table: table || "T7", items: items, status: "fire", paid: total, start: Date.now() });
      s.payments.unshift({ id: Date.now(), type: split ? "split" : "upi", amt: total, table: table || "T7", note: items });
      s.points += Math.round(total / 10);
      s.log.unshift((split ? "Split " : "Paid ") + window.KL.money(total) + " · " + items);
      items.split(",").forEach(function (name) {
        var n = name.trim().replace(/^\d+x\s*/, "");
        var d = s.dishes.find(function (x) { return x.name === n; });
        if (d) {
          d.sold += 1;
          d.rev += Math.round(total / Math.max(1, items.split(",").length));
        }
      });
      save(s);
      return s;
    },
    refund: function (amt, note) {
      var s = load();
      amt = amt || s.lastPay || 0;
      if (!amt) return s;
      s.refunds += amt;
      s.sales = Math.max(0, s.sales - amt);
      s.upi = Math.max(0, s.upi - amt);
      s.payments.unshift({ id: Date.now(), type: "refund", amt: amt, table: "T7", note: note || "Guest refund" });
      s.log.unshift("Refund " + window.KL.money(amt) + " · " + (note || "T7"));
      save(s);
      return s;
    },
    toggle86: function (dish) {
      var s = load();
      var i = s.eightySix.indexOf(dish);
      if (i >= 0) s.eightySix.splice(i, 1);
      else s.eightySix.push(dish);
      s.log.unshift((i >= 0 ? "86 lifted: " : "86: ") + dish);
      save(s);
      return s;
    }
  };
})();
