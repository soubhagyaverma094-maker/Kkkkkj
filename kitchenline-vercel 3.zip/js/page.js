function svg(name) {
  const icons = {
    back: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M15 6l-6 6 6 6" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>',
    call: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M7 4h3l1.5 4-2 1.2a12 12 0 0 0 5.3 5.3L16 12.5l4 1.5v3a2 2 0 0 1-2.2 2A16 16 0 0 1 5 8.2 2 2 0 0 1 7 6z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg>',
    more: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><circle cx="5" cy="12" r="1.5" fill="currentColor"/><circle cx="12" cy="12" r="1.5" fill="currentColor"/><circle cx="19" cy="12" r="1.5" fill="currentColor"/></svg>',
    send: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M4 12l16-7-7 16-2-7-7-2z" stroke="#07342c" stroke-width="1.8" stroke-linejoin="round"/></svg>'
  };
  return icons[name] || "";
}
