(function () {
  const root = document.querySelector("[data-chat]");
  if (!root) return;

  const thread = root.querySelector(".thread");
  const actions = root.querySelector(".actions");
  const input = root.querySelector("[data-input]");
  const sendBtn = root.querySelector("[data-send]");
  const script = window.CHAT_SCRIPT;
  if (!script) return;

  const state = { step: script.start, cart: [], pax: 4, time: "8:00 PM", total: 0 };

  function now() {
    return new Date().toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" });
  }

  function el(html) {
    const wrap = document.createElement("div");
    wrap.innerHTML = html.trim();
    return wrap.firstElementChild;
  }

  function scroll() {
    thread.scrollTop = thread.scrollHeight;
  }

  function ticks() {
    return '<svg width="14" height="10" viewBox="0 0 16 11" fill="none"><path d="M1 6.2L4.4 9.5L11.5 1.5" stroke="#53bdeb" stroke-width="1.6"/><path d="M5 6.2L8.4 9.5L15.5 1.5" stroke="#53bdeb" stroke-width="1.6"/></svg>';
  }

  function bubble(msg, side) {
    const node = el(
      `<div class="bubble ${side}">${msg.html || msg.text}<div class="meta">${now()}${side === "out" ? ticks() : ""}</div></div>`
    );
    thread.appendChild(node);
    scroll();
  }

  function typing() {
    const node = el('<div class="bubble in typing" aria-hidden="true"><i></i><i></i><i></i></div>');
    thread.appendChild(node);
    scroll();
    return node;
  }

  function renderChoices(choices) {
    actions.innerHTML = "";
    if (!choices || !choices.length) {
      actions.innerHTML = '<span style="color:#8696a0;font-size:0.78rem;padding:8px 4px">Conversation complete. Refresh to replay.</span>';
      return;
    }
    choices.forEach(function (choice) {
      const btn = document.createElement("button");
      btn.className = "choice" + (choice.ghost ? " ghost" : "");
      btn.type = "button";
      btn.textContent = choice.label;
      btn.addEventListener("click", function () {
        take(choice);
      });
      actions.appendChild(btn);
    });
  }

  function interpolate(str) {
    return String(str || "")
      .replace(/\{total\}/g, state.total.toLocaleString("en-IN"))
      .replace(/\{pax\}/g, state.pax)
      .replace(/\{time\}/g, state.time)
      .replace(/\{cart\}/g, state.cart.join(", ") || "nothing yet");
  }

  function take(choice) {
    if (choice.price) state.total += choice.price;
    if (choice.item) state.cart.push(choice.item);
    if (choice.pax) state.pax = choice.pax;
    if (choice.time) state.time = choice.time;
    bubble({ text: interpolate(choice.say || choice.label) }, "out");
    go(choice.next);
  }

  function go(id) {
    const step = script.steps[id];
    if (!step) return;
    state.step = id;
    renderChoices([]);
    const wait = typing();
    window.setTimeout(function () {
      wait.remove();
      (step.messages || []).forEach(function (msg) {
        const copy = { text: interpolate(msg.text), html: msg.html ? interpolate(msg.html) : null };
        bubble(copy, "in");
      });
      renderChoices(step.choices);
    }, step.delay || 650);
  }

  if (sendBtn && input) {
    function submit() {
      const value = input.value.trim();
      if (!value) return;
      input.value = "";
      bubble({ text: value }, "out");
      const step = script.steps[state.step];
      const fallback = (step && step.freeNext) || script.fallback;
      go(fallback);
    }
    sendBtn.addEventListener("click", submit);
    input.addEventListener("keydown", function (e) {
      if (e.key === "Enter") submit();
    });
  }

  if (script.intro) {
    thread.appendChild(el('<div class="day">Today</div>'));
    script.intro.forEach(function (msg) {
      bubble({ text: interpolate(msg.text), html: msg.html }, "in");
    });
  }
  renderChoices((script.steps[script.start] || {}).choices);
})();
